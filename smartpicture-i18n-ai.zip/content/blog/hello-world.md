---
title: Hello World
description: First post of SmartPicture.
---

# Hello World

This is the first post. We will translate it to multiple languages and add SEO automatically.
